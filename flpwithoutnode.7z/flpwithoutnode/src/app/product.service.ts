import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { Product } from './Product';


@Injectable({
  providedIn: 'root'
})
export class ProductService {
// url="http://localhost:8098/productt/";

  constructor(private httpClient:HttpClient) { }

//  pro:Observable<Product>;

 public showProducts(mid:number): Observable<Product>
 {
  console.log(mid);
let url='http://localhost:8098/productt/'+mid;
 return this.httpClient.get<Product>(url);
 }

//public getbyid(mid): Observable<Product[]>
 //{

 //console.log(mid);
//return this.httpClient.get<Product[]>("http://localhost:8098/productt/"+mid);
 
 //}
}
