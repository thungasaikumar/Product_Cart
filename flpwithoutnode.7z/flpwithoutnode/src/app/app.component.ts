import { Component } from '@angular/core';
import { ProductService } from './product.service';
import { Product } from './Product';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'flp';
  pro:Product;

  constructor(private ProductService: ProductService) { }

  showProducts(mid) {
    this.ProductService.showProducts(mid).subscribe(data =>{
      this.pro=data;
alert("abcd");
  });
}
}
