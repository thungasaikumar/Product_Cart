export class Product
{
 id:number;
 fid:number;
 mid:number;
 name:String;
 brand:String;
 description:String;
 model:String;
 price:number;
 custfeed:String;
}